#! /bin/bash
FILE="hg19.gtf"

for chr in $(cut -f1 $FILE | sort | uniq)
do 
	echo "Found chromosome $chr in file $FILE"
done
