#! /bin/bash

for file in *.txt
do
	echo "Found text file $file"
done
