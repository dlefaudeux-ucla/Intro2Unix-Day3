#! /bin/bash

for chr in $(cut -f1 $1 | sort | uniq)
do 
	mkdir $chr
	awk -F '\t' -v OFS='\t' -v chr=$chr '$1==chr {print}' $1 > $chr/$chr.gtf
done

