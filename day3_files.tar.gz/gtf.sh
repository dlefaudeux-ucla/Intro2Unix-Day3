#!/bin/bash

mkdir chr2 chr3 chr21

awk -F '\t' -v OFS='\t' '$1=="chr2" {print}' hg19.gtf > chr2/chr2.gtf
awk -F '\t' -v OFS='\t' '$1=="chr3" {print}' hg19.gtf > chr3/chr3.gtf
awk -F '\t' -v OFS='\t' '$1=="chr21" {print}' hg19.gtf > chr21/chr21.gtf

